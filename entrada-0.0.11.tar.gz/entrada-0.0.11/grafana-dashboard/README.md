## rafana-dashboard

Grafana dashboards used to monitor Entrada.

## License

This project is distributed under GNU General Public License, version 3
See [LICENSE](LICENSE).