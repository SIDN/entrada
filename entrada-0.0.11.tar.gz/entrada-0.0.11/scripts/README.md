## Scripts
This project contains workflow scripts used to automate Entrada processing steps.

## License

This project is distributed under GNU General Public License, version 3
See [LICENSE](LICENSE).