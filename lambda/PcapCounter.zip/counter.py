import boto3, re, json, os

def main(notification, context):
    event = json.loads(notification["Records"][0]["Sns"]["Message"])
    s3info = event["Records"][0]["s3"]
    s3client = boto3.client("s3")
    
    bucket = s3info["bucket"]["name"]
    key = s3info["object"]["key"]
    path = re.match(r"^(([\w\.]*/)*)[\w\.]*/[\w\.]+\.pcap$", key) #path.group(1) will be the input dir since key is in a subdir of input
    
    max = 1
    objects = s3client.list_objects_v2(Bucket=bucket, Prefix=path.group(1), MaxKeys=max)
    if objects["KeyCount"] == max:
        env = os.environ
        
        payload = {
            "Mode": "processing",
            "SafeLock": True,
            "Bucket": bucket,
            "Path": path.group(1).replace("input/", ""),
            "EMRconfig": {
                "Instances": {
                    "Ec2KeyName": env["KeyPair"]
                }
            }
        }
        
        awsLambda = boto3.client("lambda")
        response = awsLambda.invoke(
            FunctionName = env["booter"],
            InvocationType = "Event",
            Payload = json.dumps(payload)
            )
        return str(response)
    else:
        return f"{objects['KeyCount']} file(s) in input, won't start processing"
